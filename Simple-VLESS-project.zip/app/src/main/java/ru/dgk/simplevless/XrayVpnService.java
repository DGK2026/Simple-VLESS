package ru.dgk.simplevless;

import android.app.*;
import android.content.*;
import android.net.VpnService;
import android.os.*;
import org.json.*;
import libXray.DialerController;
import libXray.LibXray;

public class XrayVpnService extends VpnService {
    public static final String START="ru.dgk.simplevless.START", STOP="ru.dgk.simplevless.STOP";
    public static final String STATUS_ACTION="ru.dgk.simplevless.VPN_STATUS";
    ParcelFileDescriptor tun;
    final DialerController controller = new DialerController() {
        @Override public boolean protectFd(long fd) { return protect((int)fd); }
    };
    void publishStatus(String message, boolean failed) {
        getSharedPreferences("vpn_state",0).edit().putString("message",message).apply();
        Intent event = new Intent(STATUS_ACTION).setPackage(getPackageName()).putExtra("message",message).putExtra("failed",failed);
        sendBroadcast(event);
    }
    @Override public void onCreate(){
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("vpn", "Simple VLESS", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
    private Notification buildNotification() {
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, "vpn")
            : new Notification.Builder(this);
        return nb.setContentTitle("Simple VLESS")
            .setContentText("VPN подключается")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .build();
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&STOP.equals(i.getAction())){
            stopCore();
            publishStatus("Отключено",false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if(i!=null&&START.equals(i.getAction())) {
            try {
                // Replace the active tunnel before starting the newly selected profile.
                stopCore();
                // Android requires foreground promotion immediately after startForegroundService().
                startForeground(1, buildNotification());
                new Thread(()->startCore(i)).start();
            } catch (Exception e) {
                publishStatus("Ошибка VPN: " + e.getClass().getSimpleName() + ": " + e.getMessage(), true);
                stopCore();
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }
    void startCore(Intent intent){
        try {
            publishStatus("VPN запускается…",false);
            Builder builder = new Builder().setSession("Simple VLESS").setMtu(1500)
                .addAddress("198.18.0.1",15).addRoute("0.0.0.0",0).addDnsServer("1.1.1.1")
                .addAddress("fd00:1:fd00:1::1",126).addRoute("::",0);
            java.util.ArrayList<String> apps=intent.getStringArrayListExtra("apps");
            if(apps!=null&&!apps.isEmpty()){
                int added=0;
                for(String pkg:apps){
                    try { getPackageManager().getApplicationInfo(pkg,0); builder.addAllowedApplication(pkg); added++; }
                    catch(android.content.pm.PackageManager.NameNotFoundException ignored) {}
                }
                if(added==0) throw new IllegalStateException("В выбранном списке нет установленных приложений");
            }
            tun=builder.establish();
            if(tun==null) throw new IllegalStateException("Android не создал VPN-интерфейс");
            LibXray.registerDialerController(controller);
            LibXray.setDNS(controller,"1.1.1.1:53");
            JSONObject outbound=new JSONObject(intent.getStringExtra("outbound"));
            JSONArray outbounds=new JSONArray().put(outbound).put(new JSONObject().put("tag","direct").put("protocol","freedom")).put(new JSONObject().put("tag","block").put("protocol","blackhole"));
            JSONObject tunIn=new JSONObject().put("tag","tun-in").put("protocol","tun").put("settings",new JSONObject().put("name","xray0").put("MTU",1500));
            JSONObject cfg=new JSONObject().put("log",new JSONObject().put("loglevel","warning"))
                .put("inbounds",new JSONArray().put(tunIn)).put("outbounds",outbounds)
                .put("routing",new JSONObject().put("rules",new JSONArray().put(new JSONObject().put("type","field").put("inboundTag",new JSONArray().put("tun-in")).put("outboundTag","proxy"))));
            cfg.put("env",new JSONObject().put("xray.tun.fd",Integer.toString(tun.getFd())));
            JSONObject request=new JSONObject().put("apiVersion",3).put("method","runXray").put("payload",new JSONObject().put("xrayJson",cfg.toString()));
            JSONObject response=new JSONObject(LibXray.invoke(request.toString()));
            if(!response.optBoolean("success")) throw new IllegalStateException(response.optString("error","Xray start failed"));
            publishStatus("VPN подключён",false);
        } catch(Exception e){
            android.util.Log.e("SimpleVLESS","VPN start failed",e);
            String message = e.getClass().getSimpleName() + (e.getMessage()==null ? "" : ": " + e.getMessage());
            publishStatus("Ошибка VPN: " + message,true);
            stopCore(); stopSelf();
        }
    }
    void stopCore(){
        try { JSONObject r=new JSONObject().put("apiVersion",3).put("method","stopXray").put("payload",new JSONObject()); LibXray.invoke(r.toString()); LibXray.resetDNS(); } catch(Exception ignored){}
        try{if(tun!=null)tun.close();}catch(Exception ignored){} tun=null;
        stopForeground(STOP_FOREGROUND_REMOVE);
    }
    @Override public void onRevoke(){stopCore();stopSelf();super.onRevoke();}
    @Override public void onDestroy(){stopCore();super.onDestroy();}
}
