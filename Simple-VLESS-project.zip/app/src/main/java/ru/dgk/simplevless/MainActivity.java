package ru.dgk.simplevless;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int VPN_REQUEST=51;
    LinearLayout root, list;
    TextView status;
    EditText importBox;
    JSONArray profiles;
    int selected=0;
    ArrayList<String> packages=new ArrayList<>();
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,19,26));
        getWindow().setNavigationBarColor(Color.rgb(16,19,26));
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,20); root.setBackgroundColor(Color.rgb(16,19,26));
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView title=text("SIMPLE VLESS",25,true); root.addView(title);
        status=text("Отключено",15,false); status.setTextColor(Color.rgb(150,160,175)); root.addView(status);
        Button connect=button("ПОДКЛЮЧИТЬ"); root.addView(connect);
        connect.setOnClickListener(v->startVpn());
        TextView h=text("Серверы и подписки",19,true); root.addView(h);
        list=new LinearLayout(this); list.setOrientation(1); root.addView(list);
        importBox=new EditText(this); importBox.setHint("Вставь vless:// или URL подписки"); importBox.setTextColor(Color.WHITE); importBox.setHintTextColor(0xff8892a3); root.addView(importBox);
        Button add=button("Добавить ссылку / подписку"); root.addView(add);
        add.setOnClickListener(v->importText(importBox.getText().toString()));
        Button clip=button("Вставить из буфера обмена"); root.addView(clip);
        clip.setOnClickListener(v->{ android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); if(cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0) importText(String.valueOf(cm.getPrimaryClip().getItemAt(0).coerceToText(this))); });
        TextView split=text("Раздельное туннелирование",19,true); root.addView(split);
        TextView note=text("Отметь приложения, которые должны идти через VPN. Если ничего не отмечено — через VPN пойдёт весь трафик.",13,false); root.addView(note);
        Button refresh=button("Обновить список приложений"); root.addView(refresh); refresh.setOnClickListener(v->showApps());
        showProfiles();
    }
    TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE); if(bold)t.setTypeface(null,1); t.setPadding(0,14,0,10); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff246b59)); b.setAllCaps(false); return b; }
    void importText(String raw) {
        new Thread(()->{ try {
            String content=raw.trim();
            if(content.startsWith("http://")||content.startsWith("https://")) {
                HttpURLConnection c=(HttpURLConnection)new URL(content).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","SimpleVLESS/0.1"); InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); content=VlessParser.decodeSubscription(new String(out.toByteArray(),StandardCharsets.UTF_8));
            }
            String[] lines=content.split("[\\r\\n]+"); int count=0;
            for(String line:lines) if(line.trim().startsWith("vless://")) { ProfileStore.add(this,line.trim()); count++; }
            final int total=count; runOnUiThread(()->{ importBox.setText(""); showProfiles(); toast(total>0?"Добавлено профилей: "+total:"VLESS-ссылки не найдены"); });
        } catch(Exception e){runOnUiThread(()->toast("Ошибка импорта: "+e.getMessage()));}});
    }
    void showProfiles(){
        profiles=ProfileStore.all(this); list.removeAllViews();
        for(int i=0;i<profiles.length();i++){ final int idx=i; JSONObject p=profiles.optJSONObject(i); Button b=button((i==selected?"✓ ":"")+" "+p.optString("name")+"  ·  "+p.optString("server")); list.addView(b); b.setOnClickListener(v->{selected=idx; showProfiles();}); }
    }
    void showApps(){
        list.removeAllViews(); // profile list remains available above; app list is rendered below
        try {
            for(android.content.pm.ApplicationInfo a:getPackageManager().getInstalledApplications(0)){
                if(a.packageName.equals(getPackageName())) continue;
                CheckBox cb=new CheckBox(this); cb.setText(getPackageManager().getApplicationLabel(a)+"  ("+a.packageName+")"); cb.setTextColor(Color.WHITE); cb.setTag(a.packageName); cb.setChecked(packages.contains(a.packageName));
                cb.setOnCheckedChangeListener((v,on)->{if(on&&!packages.contains(a.packageName))packages.add(a.packageName); if(!on)packages.remove(a.packageName);}); root.addView(cb);
            }
            toast("Выбор приложений сохранён до закрытия приложения");
        } catch(Exception e){toast(e.getMessage());}
    }
    void startVpn(){
        if(profiles.length()==0){toast("Сначала добавь VLESS-профиль");return;}
        Intent prepare=VpnService.prepare(this);
        if(prepare!=null) startActivityForResult(prepare,VPN_REQUEST);
        else onActivityResult(VPN_REQUEST,RESULT_OK,null);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(req==VPN_REQUEST&&res==RESULT_OK){
        try { JSONObject p=profiles.getJSONObject(selected); Intent i=new Intent(this,XrayVpnService.class).setAction(XrayVpnService.START).putExtra("outbound",p.getJSONObject("outbound").toString()).putStringArrayListExtra("apps",packages); if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i); status.setText("Запуск…"); }
        catch(Exception e){toast(e.getMessage());}
    }}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
