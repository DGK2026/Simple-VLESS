package ru.dgk.simplevless;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import libXray.LibXray;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int VPN_REQUEST = 51;
    LinearLayout root, list, appsList;
    TextView status;
    EditText importBox;
    JSONArray profiles;
    int selected = 0;
    ArrayList<String> packages = new ArrayList<>();
    boolean receiverRegistered = false;

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (XrayVpnService.STATUS_ACTION.equals(intent.getAction())) {
                String message = intent.getStringExtra("message");
                boolean failed = intent.getBooleanExtra("failed", false);
                status.setText(message == null ? "Состояние изменено" : message);
                if (failed && message != null) showMessage("Ошибка VPN", message);
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,19,26));
        getWindow().setNavigationBarColor(Color.rgb(16,19,26));
        root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(22,24,22,20);
        root.setBackgroundColor(Color.rgb(16,19,26));
        ScrollView sc = new ScrollView(this);
        sc.addView(root);
        setContentView(sc);

        root.addView(text("SIMPLE VLESS",25,true));
        status = text("Отключено",15,false);
        status.setTextColor(Color.rgb(150,190,175));
        root.addView(status);

        Button connect = button("ПОДКЛЮЧИТЬ");
        root.addView(connect);
        connect.setOnClickListener(v -> startVpn());
        Button disconnect = button("ОТКЛЮЧИТЬ");
        root.addView(disconnect);
        disconnect.setOnClickListener(v -> stopVpn());

        root.addView(text("Серверы и подписки",19,true));
        list = new LinearLayout(this);
        list.setOrientation(1);
        root.addView(list);
        importBox = new EditText(this);
        importBox.setHint("Вставь vless:// или URL подписки");
        importBox.setTextColor(Color.WHITE);
        importBox.setHintTextColor(0xff8892a3);
        importBox.setSingleLine(false);
        root.addView(importBox);

        Button add = button("Добавить ссылку / подписку");
        root.addView(add);
        add.setOnClickListener(v -> importText(importBox.getText().toString()));
        Button clip = button("Вставить из буфера обмена");
        root.addView(clip);
        clip.setOnClickListener(v -> pasteFromClipboard());

        root.addView(text("Раздельное туннелирование",19,true));
        root.addView(text("Отметь приложения, которые должны идти через VPN. Если ничего не отмечено — через VPN пойдёт весь трафик.",13,false));
        Button refresh = button("Обновить список приложений");
        root.addView(refresh);
        refresh.setOnClickListener(v -> showApps());
        appsList = new LinearLayout(this);
        appsList.setOrientation(1);
        root.addView(appsList);

        IntentFilter filter = new IntentFilter(XrayVpnService.STATUS_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(vpnReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(vpnReceiver, filter);
        receiverRegistered = true;

        showProfiles();
        // Populate split-tunneling choices on first launch; do not leave a blank area.
        showApps();
        refreshVpnState();
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshVpnState();
    }

    // Never trust the last saved status text: it may be left behind after Android
    // kills the app/service. Ask libXray for the actual core state instead.
    void refreshVpnState() {
        new Thread(() -> {
            String message = "Отключено";
            try {
                JSONObject request = new JSONObject()
                    .put("apiVersion", 3)
                    .put("method", "getXrayState")
                    .put("payload", new JSONObject());
                JSONObject response = new JSONObject(LibXray.invoke(request.toString()));
                if (!response.optBoolean("success")) {
                    throw new IllegalStateException(response.optString("error", "Не удалось проверить состояние VPN"));
                }
                JSONObject data = response.optJSONObject("data");
                if (data != null && data.optBoolean("running", false)) message = "VPN подключён";
            } catch (Exception e) {
                message = "Состояние VPN не удалось проверить: " + describe(e);
            }
            final String actual = message;
            runOnUiThread(() -> { if (status != null) status.setText(actual); });
        }).start();
    }

    TextView text(String s,int size,boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(null,1);
        t.setPadding(0,14,0,10);
        return t;
    }
    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff246b59));
        b.setAllCaps(false);
        return b;
    }
    void showMessage(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("Понятно", null).show();
    }
    void pasteFromClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            ClipData clip = cm == null ? null : cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) {
                showMessage("Буфер обмена", "В буфере обмена нет текста.");
                return;
            }
            importBox.setText(clip.getItemAt(0).coerceToText(this));
            status.setText("Ссылка вставлена. Нажми «Добавить ссылку / подписку».");
        } catch (Exception e) { showMessage("Ошибка буфера обмена", describe(e)); }
    }
    String describe(Throwable e) {
        String m = e.getMessage();
        return e.getClass().getSimpleName() + (m == null ? "" : ": " + m);
    }

    void importText(String raw) {
        final String input = raw == null ? "" : raw.trim();
        if (input.isEmpty()) {
            showMessage("Импорт", "Сначала вставь VLESS-ссылку или URL подписки в поле выше.");
            return;
        }
        status.setText("Импортирую ссылку…");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String content = input;
                if (content.startsWith("http://") || content.startsWith("https://")) {
                    connection = (HttpURLConnection)new URL(content).openConnection();
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(30000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "SimpleVLESS/0.2");
                    int code = connection.getResponseCode();
                    if (code < 200 || code >= 300) throw new IllegalStateException("Сервер подписки ответил HTTP " + code);
                    try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) != -1) out.write(buf,0,n);
                        content = VlessParser.decodeSubscription(new String(out.toByteArray(), StandardCharsets.UTF_8));
                    }
                }
                String[] lines = content.split("[\\r\\n]+");
                int count = 0;
                int invalid = 0;
                StringBuilder errors = new StringBuilder();
                for (String line : lines) {
                    String item = line.trim();
                    if (item.regionMatches(true,0,"vless://",0,8)) {
                        try { ProfileStore.add(getApplicationContext(), item); count++; }
                        catch (Exception ex) {
                            invalid++;
                            if (errors.length() < 500) errors.append(describe(ex)).append('\n');
                        }
                    }
                }
                final int added = count;
                final int bad = invalid;
                final String details = errors.toString();
                runOnUiThread(() -> {
                    profiles = ProfileStore.all(this);
                    if (profiles.length() > 0 && selected >= profiles.length()) selected = profiles.length()-1;
                    showProfiles();
                    if (added > 0) {
                        importBox.setText("");
                        status.setText("Импорт завершён. Профилей в списке: " + profiles.length());
                        if (bad > 0) showMessage("Импорт завершён", "Добавлено: " + added + "\nОшибок: " + bad + "\n\n" + details);
                    } else {
                        status.setText("Импорт не выполнен");
                        String reason = bad > 0 ? details : "В полученном тексте не найдены ссылки vless://. Проверь ссылку или формат подписки.";
                        showMessage("Не удалось добавить профиль", reason);
                    }
                });
            } catch (Exception e) {
                final String error = describe(e);
                runOnUiThread(() -> { status.setText("Ошибка импорта"); showMessage("Ошибка импорта", error); });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    void showProfiles() {
        profiles = ProfileStore.all(this);
        list.removeAllViews();
        if (profiles.length() == 0) {
            TextView empty = text("Профилей пока нет. Вставь VLESS-ссылку выше.",14,false);
            empty.setTextColor(0xffaab4c3);
            list.addView(empty);
            return;
        }
        if (selected >= profiles.length()) selected = 0;
        for (int i=0; i<profiles.length(); i++) {
            final int idx = i;
            JSONObject p = profiles.optJSONObject(i);
            if (p == null) continue;
            Button b = button((i == selected ? "✓ " : "") + p.optString("name") + " · " + p.optString("server"));
            list.addView(b);
            b.setOnClickListener(v -> { selected = idx; showProfiles(); status.setText("Выбран сервер: " + p.optString("name")); });
        }
    }
    void showApps() {
        appsList.removeAllViews();
        try {
            int count = 0;
            for (android.content.pm.ApplicationInfo a : getPackageManager().getInstalledApplications(0)) {
                if (a.packageName.equals(getPackageName())) continue;
                CheckBox cb = new CheckBox(this);
                cb.setText(getPackageManager().getApplicationLabel(a) + "  (" + a.packageName + ")");
                cb.setTextColor(Color.WHITE); cb.setTag(a.packageName);
                cb.setChecked(packages.contains(a.packageName));
                cb.setOnCheckedChangeListener((v,on) -> { if(on && !packages.contains(a.packageName)) packages.add(a.packageName); if(!on) packages.remove(a.packageName); });
                appsList.addView(cb); count++;
            }
            status.setText("Список приложений загружен: " + count);
        } catch (Exception e) { showMessage("Список приложений", describe(e)); }
    }
    void startVpn() {
        profiles = ProfileStore.all(this);
        if (profiles.length() == 0) { showMessage("Нет профиля", "Сначала добавь VLESS-ссылку или подписку."); return; }
        if (selected < 0 || selected >= profiles.length()) selected = 0;
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, VPN_REQUEST);
        else onActivityResult(VPN_REQUEST, RESULT_OK, null);
    }
    void stopVpn() {
        Intent i = new Intent(this, XrayVpnService.class).setAction(XrayVpnService.STOP);
        // STOP does not start a foreground operation; starting it with startForegroundService
        // would require a foreground notification even though the service is stopping.
        startService(i);
        status.setText("Отключение…");
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if (req == VPN_REQUEST) {
            if (res != RESULT_OK) { status.setText("Подключение отменено: разрешение VPN не выдано"); return; }
            try {
                JSONObject p = profiles.getJSONObject(selected);
                Intent i = new Intent(this,XrayVpnService.class).setAction(XrayVpnService.START)
                    .putExtra("outbound",p.getJSONObject("outbound").toString())
                    .putStringArrayListExtra("apps",packages);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                status.setText("Запуск VPN…");
            } catch(Exception e) { showMessage("Не удалось запустить VPN", describe(e)); }
        }
    }
    @Override protected void onDestroy() {
        if (receiverRegistered) { unregisterReceiver(vpnReceiver); receiverRegistered = false; }
        super.onDestroy();
    }
}
