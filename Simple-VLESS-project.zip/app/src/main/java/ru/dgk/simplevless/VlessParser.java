package ru.dgk.simplevless;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

final class VlessParser {
    static JSONObject parse(String raw) throws Exception {
        URI u = new URI(raw.trim());
        if (!"vless".equalsIgnoreCase(u.getScheme())) throw new IllegalArgumentException("Поддерживаются ссылки vless://");
        String id = u.getUserInfo();
        String host = u.getHost();
        int port = u.getPort();
        if (id == null || host == null || port < 1) throw new IllegalArgumentException("Неверная VLESS-ссылка");
        Map<String,String> q = query(u.getRawQuery());
        String name = u.getFragment() == null ? host : URLDecoder.decode(u.getFragment(), "UTF-8");
        JSONObject stream = new JSONObject();
        String net = q.getOrDefault("type","tcp");
        String sec = q.getOrDefault("security","none");
        stream.put("network", net);
        if ("reality".equals(sec)) {
            JSONObject reality = new JSONObject();
            reality.put("serverName", q.getOrDefault("sni",host));
            reality.put("fingerprint", q.getOrDefault("fp","chrome"));
            reality.put("publicKey", q.getOrDefault("pbk",""));
            reality.put("shortId", q.getOrDefault("sid",""));
            if (q.containsKey("spx")) reality.put("spiderX",q.get("spx"));
            stream.put("security","reality").put("realitySettings",reality);
        } else if ("tls".equals(sec)) {
            JSONObject tls = new JSONObject();
            tls.put("serverName",q.getOrDefault("sni",host));
            tls.put("fingerprint",q.getOrDefault("fp","chrome"));
            if (q.containsKey("alpn")) tls.put("alpn",new JSONArray(java.util.Arrays.asList(q.get("alpn").split(","))));
            stream.put("security","tls").put("tlsSettings",tls);
        } else stream.put("security","none");
        if ("ws".equals(net)) {
            JSONObject ws = new JSONObject().put("path",q.getOrDefault("path",""));
            if (q.containsKey("host")) ws.put("headers",new JSONObject().put("Host",q.get("host")));
            stream.put("wsSettings",ws);
        } else if ("grpc".equals(net)) {
            stream.put("grpcSettings",new JSONObject().put("serviceName",q.getOrDefault("serviceName",q.getOrDefault("service_name",""))));
        } else if ("xhttp".equals(net)) {
            JSONObject x = new JSONObject().put("path",q.getOrDefault("path","/"));
            if(q.containsKey("mode")) x.put("mode",q.get("mode"));
            stream.put("xhttpSettings",x);
        }
        JSONObject user = new JSONObject().put("id",id).put("encryption",q.getOrDefault("encryption","none"));
        if(q.containsKey("flow") && !q.get("flow").isEmpty()) user.put("flow",q.get("flow"));
        JSONObject outbound = new JSONObject().put("tag","proxy").put("protocol","vless")
            .put("settings",new JSONObject().put("vnext",new JSONArray().put(
                new JSONObject().put("address",host).put("port",port).put("users",new JSONArray().put(user)))))
            .put("streamSettings",stream);
        return new JSONObject().put("name",name).put("server",host).put("outbound",outbound);
    }
    static Map<String,String> query(String raw) throws Exception {
        Map<String,String> m = new LinkedHashMap<>();
        if(raw==null) return m;
        for(String pair:raw.split("&")) {
            String[] p=pair.split("=",2);
            m.put(URLDecoder.decode(p[0],"UTF-8"),p.length>1?URLDecoder.decode(p[1],"UTF-8"):"");
        }
        return m;
    }
    static String decodeSubscription(String s) {
        String t=s.trim();
        if(t.startsWith("vless://")) return t;
        try {
            String b=new String(Base64.decode(t,Base64.DEFAULT),StandardCharsets.UTF_8).trim();
            if(b.contains("://")) return b;
        } catch(Exception ignored) {}
        return t;
    }
}
