package ru.dgk.simplevless;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class ProfileStore {
    private static final String PREF = "profiles";
    static JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF,0).getString("items","[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREF,0).edit().putString("items",a.toString()).apply();
    }
    static void add(Context c, String link) throws Exception {
        JSONObject p = VlessParser.parse(link);
        JSONArray a = all(c);
        for (int i=0;i<a.length();i++) if (a.getJSONObject(i).optString("link").equals(link)) return;
        p.put("link",link); a.put(p); save(c,a);
    }
}
