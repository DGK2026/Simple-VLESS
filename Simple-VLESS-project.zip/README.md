# Simple VLESS (prototype)

Android VLESS client based on the official XTLS/libXray Android AAR.

## Build
Push to `main` or run **Actions → Build Android APK → Run workflow**.
Download `Simple-VLESS-debug-apk` from the completed workflow run.

## Important status
This is an initial engineering prototype, not a release-ready VPN client. The UI/import flow and build pipeline are provided, but TUN integration and per-app routing require device-level validation against the current libXray/Xray-core release. Do not use it for sensitive traffic until those tests pass.

Supported import target: VLESS URI links. Subscription URLs returning a plain list of VLESS URIs or a Base64-encoded list are handled.


## Исправления версии 0.3.0
- Убран показ сохранённого текста статуса VPN: при запуске приложение запрашивает фактическое состояние Xray через `getXrayState`.
- Список приложений для раздельного туннелирования загружается автоматически при открытии главного экрана.
- Повышены `versionCode` и `versionName`, чтобы Android отличал новую сборку от старой.

Сборка APK сама по себе не подтверждает подключение к серверу: проверка реального VPN требует установки и запуска на Android-устройстве.
